import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import com.fazecast.jSerialComm.SerialPort;
import java.awt.Color;
import java.awt.Dimension;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;


public class AP_1_2 extends javax.swing.JFrame{

    //globale variablen
    static SerialPort chosenPort;
    static int x = 0;
    private static OutputStream Output;
    static String[] result = new String[99999];
        

	public static void main(String[] args) {
		
            // Erzeugen der GUI-Oberfläche
            JFrame window = new JFrame();
            window.setTitle("GUI");
            window.setSize(600, 400);
            window.setLayout(new BorderLayout());
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Erzeugen der DropDown-Liste und des Connect-Buttons
            JComboBox<String> portList_combobox = new JComboBox<String>();
            JButton connectButton = new JButton("Connect");
            JPanel topPanel = new JPanel();
            
            topPanel.add(portList_combobox);
            topPanel.add(connectButton);
            window.add(topPanel, BorderLayout.NORTH);
            
            // Erzeugen des Pause/Start-Buttons
            JButton PauseButton = new JButton("Start");

            // Befüllen der DropDown-Liste
            SerialPort[] portNames;
            portNames = SerialPort.getCommPorts();
            
    		for(int i = 0; i < portNames.length; i++)
    			// die einzelnen unterschiedlichen Ports hinzufügen
    			portList_combobox.addItem(portNames[i].getSystemPortName());
           
    		
            // EEG-Datengraph erzeugen
    		// Graphen für die EEG-Daten erstellen, alles benennen und mittig platzieren
    		XYSeries series = new XYSeries("EEG-Daten");
    		XYSeriesCollection dataset = new XYSeriesCollection(series);
    		JFreeChart chart = ChartFactory.createXYLineChart("EEG-Output", "Time (sekunden)", "EEG-Werte", dataset);
    		    
            // Design des Gui
            XYLineAndShapeRenderer r1 = new XYLineAndShapeRenderer();
            r1.setSeriesPaint(0, Color.red); 
            XYPlot plot = chart.getXYPlot();
            plot.setRenderer(0,r1);            
            plot.setBackgroundPaint(Color.black);
            plot.setDomainGridlinePaint(Color.green);
            plot.setRangeGridlinePaint(Color.green);         
           
            ChartPanel cp = new ChartPanel(chart);
            window.add(cp, BorderLayout.CENTER);
            
            // erzeugen des Pause/Start-Buttons
            window.add(PauseButton,BorderLayout.AFTER_LAST_LINE);
            PauseButton.setEnabled(false);
            
            
            //Funktion des Pause/Start-Buttons
            PauseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	// Wenn am Button "Start" steht, schau ob der Port offen ist
                if (PauseButton.getText().equalsIgnoreCase("Start")) {
                    // Wenn der Port offen ist, versuche ein "v" an das Board zu senden
                	if(chosenPort.isOpen())
                    {
                        try {
                        	// "v" sollte board aktivieren und Daten schicken
                            Output.write('v');
                        } catch (IOException ex) {
                            Logger.getLogger(AP_1_2.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    // Danach den Start-Button auf "Pause" setzen                   
                    PauseButton.setText("Pause");
                }
                else{
                	// Falls der Port offen ist und am Button "Pause" steht
                    if(chosenPort.isOpen())
                    {
                    	// Schließe Port
                        chosenPort.closePort();
                    }
                    // Und ändere Button auf "Start"
                    PauseButton.setText("Start");
                }
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
		          
            // Definieren, was der VerbindungsButton zu tun hat
            connectButton.addActionListener(new ActionListener(){
                    @Override public void actionPerformed(ActionEvent arg0) {
                    		// Falls am Connect-Button "Connect" steht
                            if(connectButton.getText().equals("Connect")) {
                                    // versuche Verbindung zu einem der Verfügbaren Ports herzustellen
                                    chosenPort = SerialPort.getCommPort(portList_combobox.getSelectedItem().toString());
                                    chosenPort.setComPortTimeouts(SerialPort.TIMEOUT_SCANNER, 0, 0);
                                    // falls die Verbindung zu einem offenen Port hergestellt wird
                                    if(chosenPort.openPort()) {
                                    		// ändere den Text zu "Disconnect" und deaktiviere die DropDown-Liste
                                    		// und gleichzeitig ermögliche anklicken des Pause/Start-Buttons
                                            Output = chosenPort.getOutputStream();
                                            connectButton.setText("Disconnect");
                                            PauseButton.setEnabled(true);
                                            portList_combobox.setEnabled(false);
                                    }

                                 // neuer Thread der neuen Input abwartet und den Graphen befüllt
                					Thread thread = new Thread(){
                						@Override public void run() {
                							
                							// objekt um text vom Serial Port auszulesen
                							Scanner scanner = new Scanner(chosenPort.getInputStream());
                							
                							int y = 0;
                							
                							while(scanner.hasNextLine()) {
                								// try-catch block um mögliche "nicht-zahlen" abzufangen 
                								// ohne einen Programm-absturz zu verursachen
                								try {
                									//text in Zahl umwandeln   String -> Int
                									String line = scanner.nextLine();
                									int number = Integer.parseInt(line);
                									
                									//array mit eeg daten befüllen
                									result[y] = line;
                									y++;
                									
                									// CSV-Objekt erstellen
                									CsvWriter writer = new CsvWriter();
                							        
                									// Daten Array als CSV Exportieren
                									writer.exportCsv(result, "testExport.csv");	

                									// Zahl in series hinzufügen, um im GUI anzeigen zu können
                									series.add(x++, number);
                									window.repaint();
                								} catch(Exception e) {}
                							}
                							scanner.close();
                						}
                					};
                                    thread.start();
                                    
                            } else {
                                    // Verbindung vom Port trennen
                                    chosenPort.closePort();
                                    portList_combobox.setEnabled(true);
                                    PauseButton.setText("Start");
                                    PauseButton.setEnabled(false);
                                    connectButton.setText("Connect");

                            }
                    }
            });

            // GUI aktivieren
            window.setVisible(true);
	}   
}