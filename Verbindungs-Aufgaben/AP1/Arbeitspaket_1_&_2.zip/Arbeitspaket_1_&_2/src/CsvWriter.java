import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

// Hilfs-Klasse um unsere EEG-Daten als CSV-File zu speichern
public class CsvWriter {

    private final String CRLF = "\r\n";
    private String delimiter = ",";

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }
    
    public void exportCsv(String[] result, String filename) {
        try {
            FileWriter writer = new FileWriter(filename);

            for (int i = 0; i < result.length; i++) {
                for (int j = 0; j < result.length; j++) {
                    
                
                    //Das Trennzeichen einfuegen
                    if (j < result.length - 1) {
                        writer.append(delimiter);
                    }
                }
                //Das Trennzeichen und das Zeilenende einfuegen
                if (i < result.length - 1) {
                    writer.append(delimiter + CRLF);
                }
            }

            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
} 