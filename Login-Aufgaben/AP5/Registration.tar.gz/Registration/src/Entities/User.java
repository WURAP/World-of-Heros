package Entities;

public class User {

	private String email;
	private String password;
	
	public User(String email, String password) {
		this.email = email;
		this.password = password;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public String getPassword() {
		return this.password;
	}
		
	public boolean compareUser(User user) {
		return user.email.equals(this.email) && user.password.equals(this.password);
	}
	
	public boolean compareEmail(User user) {
		return user.email.equals(this.email);
		
	}
	@Override
	public String toString() {
		return "Email: " + email + "\n" + 
				"Passwort: " + password + "\n\n";
	}
}