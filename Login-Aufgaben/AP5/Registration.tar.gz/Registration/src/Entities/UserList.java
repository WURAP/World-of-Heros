package Entities;

import java.util.ArrayList;
import java.util.List;

public class UserList {

	private static ArrayList<User> userList;
	
	private UserList() {
		
	}
	
	public static ArrayList<User> getList() {
		if(userList == null) {
			userList = new ArrayList<>();
		}
		return userList;
	}

	public static boolean existEmail(User user) {
		ArrayList<User> users = getList();
		
		for(int i=0; i<users.size(); i++) {
			if(user.getEmail().equals(users.get(i).getEmail())) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean existUser(User user) {
		ArrayList<User> users = getList();
		
		//Schleife die bei 0 anfängt und es endet wenn i gleich der Anzahl der users in User ist.
		for(int i = 0; i < users.size(); i++) {
			if(user.compareUser(users.get(i))) {
				return true;
			}
		}
		return false;
	}
}