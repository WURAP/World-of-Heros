package Registrationprocess;

import static java.lang.System.out;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import org.primefaces.context.RequestContext;
import Entities.User;
import Entities.UserList;

@ManagedBean
public class Login {

   private String email_log;
   private String passwort_log;

   public String getemaillog() {
       return email_log;
   }
   public void setemaillog(String email1_log) {
       this.email_log = email1_log;
   } 
   
   public String getpasswortlog() {
       return passwort_log;
   }
   public void setpasswortlog(String passwort1_log) {
       this.passwort_log = passwort1_log;
   }
   
   public void buttonLogin() {
	   ArrayList<User> userList = UserList.getList(); 		//Eine Variable users von ArrayList mit dem Typ User wird erstellt
	   User newUser = new User(email_log, passwort_log);	//Neue Instanz von der Klasse User wird hier erzeugt

		try {
			//Mit Filewriter ist es möglich eine vorhandene Datei zu überschreiben & ...
			//...es kann ein Text an eine bereits bestehende Datei angehängt werden
			FileWriter fw = new FileWriter("/home/h1451953/SR/Desktop/login.txt");		//Pfad wohin die Textdatei liegen wird
			BufferedWriter bw = new BufferedWriter(fw);
			
			if(UserList.existUser(newUser)) {
				bw.write("Der Loginprozess mit dieser Email Adresse: " + newUser.getEmail() + " war erfolgreich.");
			}else {
				bw.write("Die Email Adresse: " + newUser.getEmail() + " existiert nicht.");
			}

		    bw.close();	//WICHTIG --> Einen Writer/OutputStream sollte man immer mit close() schließen...
						//... wenn man einen BufferedWriter schließt, wird auch der darunterliegende Stream geschlossen. 
							
		} catch (IOException e) {		//Wenn Fehler auftreten werden diese hier behandelt und ein Error ausgegeben.
			out.println("Error");
		}
	   
       RequestContext context = RequestContext.getCurrentInstance();
       FacesMessage message = null;
       boolean loggedIn = false;
       
       if(UserList.existUser(newUser)) {	//Wenn User in der Userlist existiert diesen Teil ausführen
           loggedIn = true;
           message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Der Loginprozess war erfolgreich mit dieser Email Adresse: ", email_log);
           email_log = "";
       } else {								//Wenn User nicht in der Userlist existiert diesen Teil ausführen
           loggedIn = false;
           message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Der Loginprozess war nicht erfolgreich!", "Die Email Adresse oder das Passwort ist falsch!");
       }
        
       FacesContext.getCurrentInstance().addMessage(null, message);
       context.addCallbackParam("loggedIn", loggedIn);
   }
}