package Registrationprocess;

import static java.lang.System.out;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import Entities.User;
import Entities.UserList;

@ManagedBean
public class RegistrationWithMail {
	
   private String email_reg;
   private String vorname_reg;
   private String nachname_reg;
   private String passwort_reg;
   private String passwort1_reg;

   public String getemailreg() {
       return email_reg;
   }
   public void setemailreg(String email1_reg) {
       this.email_reg = email1_reg;
   }
	   
   public String getvornamereg() {
       return vorname_reg;
   }
   public void setvornamereg(String vorname1_reg) {
       this.vorname_reg = vorname1_reg;
   }
	   
   public String getnachnamereg() {
       return nachname_reg;
   }
   public void setnachnamereg(String nachname1_reg) {
       this.nachname_reg = nachname1_reg;
   }
	   
   public String getpasswortreg() {
       return passwort_reg;
   }
   public void setpasswortreg(String passwort1_reg) {
       this.passwort_reg = passwort1_reg;
   }
	   
   public String getpasswortreg1() {
       return passwort1_reg;
   }
   public void setpasswortreg1(String passwort11_reg) {
       this.passwort1_reg = passwort11_reg;
   }
	   
   public void buttonRegistrieren() {
	   
	   ArrayList<User> users = UserList.getList();			//Eine Variable users von ArrayList mit dem Typ User wird erstellt
	   User newUser = new User(email_reg,passwort_reg); 	//Neue Instanz von der Klasse User wird hier erzeugt
	       
       if(!UserList.existEmail(newUser)) {					//Wenn die Email nicht in der UserList existiert...
		   users.add(newUser);								//...wird sie in User hinzugefügt
			try {
				//Mit Filewriter ist es möglich eine vorhandene Datei zu überschreiben & ...
				//...es kann ein Text an eine bereits bestehende Datei angehängt werden
				FileWriter fw = new FileWriter("/home/h1451953/SR/Desktop/registrationen.txt");		//Pfad wohin die Textdatei liegen wird
				BufferedWriter bw = new BufferedWriter(fw);
					
				//Schleife die bei 0 anfängt und es endet wenn i gleich der Anzahl der users in User ist.
				for(int i = 0; i < users.size(); i++) {	
					bw.write(users.get(i).toString());
				}
			    bw.close();									//WICHTIG --> Einen Writer/OutputStream sollte man immer mit close() schließen...
			    											//... wenn man einen BufferedWriter schließt, wird auch der darunterliegende Stream geschlossen. 						
			} catch (IOException e) {						//Wenn Fehler auftreten werden diese hier behandelt und ein Error ausgegeben.
				out.println("Error");
			}
       }
   }
}