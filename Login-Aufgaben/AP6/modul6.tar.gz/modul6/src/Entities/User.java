package Entities;

public class User {

	private String id;
	private String ant1;
	private String ant2;
	private String ant3;
	
	public User(String id, String ant1, String ant2, String ant3) {
		this.id=id;
		this.ant1 = ant1;
		this.ant2 = ant2;
		this.ant3 = ant3;
	}

	public String getId() {
		return id;
	}
	public String getAnt1() {
		return this.ant1;
	}
	public String getAnt2() {
		return this.ant2;
	}
	public String getAnt3() {
		return this.ant3;
	}
	
	
	
	public boolean compareUser(User user) {
		return user.id.equals(this.id) && user.ant1.equals(this.ant1)&& user.ant2.equals(this.ant2)&& user.ant3.equals(this.ant3);
	}
	
	public boolean compareId(User user) {
		return user.id.equals(this.id);
		
	}
	@Override
	public String toString() {
		return "Id: "+id+"\n"+
				"Wann sind sie geboren?: "+ant1+"\n"+
				"Welche ist Ihre Lieblingsmannschaft?: "+ant2+"\n"+
				"Wie hat Ihre erste Lehrerin geheißen?: "+ant3+"\n\n";
				
	}
}

