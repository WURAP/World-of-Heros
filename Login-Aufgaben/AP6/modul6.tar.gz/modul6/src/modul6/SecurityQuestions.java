package modul6;

import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import Entities.User;
import Entities.UserList;

@ManagedBean
public class SecurityQuestions {
	/**
	 * Variable definieren
	 * */
	private String id_secquest;
	private String antwort_eins_secquest;
	private String antwort_zwei_secquest;
	private String antwort_drei_secquest;

		/**
		 * Mit der get-Methode ruft man die Variable auf 
		 * mit return wird die Variable zurückgeschickt
		 *  */
	   public String getidsecquest() {
	       return id_secquest;
	   }
	   /** 
	    * Mit der set-Methode speichert die Werte in der Variable
	    * void verhindert es die Variable zurückzuschicken
	    * */
	   public void setidsecquest(String id1_secquest) {
	       this.id_secquest = id1_secquest;
	   }
	   
	   public String getantworteinssecquest() {
	       return antwort_eins_secquest;
	   }
	   public void setantworteinssecquest(String antwort1_eins_secquest) {
	       this.antwort_eins_secquest = antwort1_eins_secquest;
	   }
	   
	   public String getantwortzweisecquest() {
	       return antwort_zwei_secquest;
	   }
	   public void setantwortzweisecquest(String antwort2_eins_secquest) {
	       this.antwort_zwei_secquest = antwort2_eins_secquest;
	   }
	   
	   public String getantwortdreisecquest() {
	       return antwort_drei_secquest;
	   }
	   public void setantwortdreisecquest(String antwort3_eins_secquest) {
	       this.antwort_drei_secquest = antwort3_eins_secquest;
	   }
	   
	   
	   /** 
	    * Es wird ein Objekt User mit den dazugehörigen Variablen erstellt
	    * es wird geprüft, ob der User bereits existiert oder ob die Fragen richtig beantwortet sind
	    * */
	   public void buttonLogin() {
		   User user = new User(id_secquest,antwort_eins_secquest,antwort_zwei_secquest,antwort_drei_secquest);
		   
		   

		   System.out.println("----------------------------");
		   System.out.println("Login:");
	       
		   if(UserList.existUser(user)) {
			   System.out.println("Der Benutzer \""+user.getId()+"\" existiert bereits. Der Benutzer ist bereits eingeloggt");
		   }else {
			   System.out.println("Der Benutzer \""+user.getId()+"\"  existiert nicht oder die Eingaben sind falsch!");
		   }
		   System.out.println("----------------------------");
		   
	   }
}
