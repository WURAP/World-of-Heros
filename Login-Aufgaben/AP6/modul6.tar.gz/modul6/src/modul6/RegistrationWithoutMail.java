package modul6;

import java.util.ArrayList;

import javax.faces.bean.ManagedBean;

import Entities.User;
import Entities.UserList;

@ManagedBean
public class RegistrationWithoutMail {
	
	private String id_reg;
	private String antwort_eins_reg;
	private String antwort_zwei_reg;
	private String antwort_drei_reg;

	   public String getidreg() {
	       return id_reg;
	   }
	   public void setidreg(String id1_reg) {
	       this.id_reg = id1_reg;
	   }
	   
	   public String getantworteinsreg() {
	       return antwort_eins_reg;
	   }
	   public void setantworteinsreg(String antwort1_eins_reg) {
	       this.antwort_eins_reg = antwort1_eins_reg;
	   }
	   
	   public String getantwortzweireg() {
	       return antwort_zwei_reg;
	   }
	   public void setantwortzweireg(String antwort2_eins_reg) {
	       this.antwort_zwei_reg = antwort2_eins_reg;
	   }
	   
	   public String getantwortdreireg() {
	       return antwort_drei_reg;
	   }
	   public void setantwortdreireg(String antwort3_eins_reg) {
	       this.antwort_drei_reg = antwort3_eins_reg;
	   }
	   

	   public void buttonRegistrieren() {
		   ArrayList<User> users = UserList.getList();
		   User user = new User(id_reg,antwort_eins_reg,antwort_zwei_reg,antwort_drei_reg);
		   

		   System.out.println("----------------------------");
		   System.out.println("Servers state:");
		   
		   if(UserList.existId(user)) {
			   System.out.println("Der Benutzer kann nicht registriert werden! Die ID existiert bereits!");
		   }else {
			   users.add(user);
			   System.out.println("Der Benutzer ist registriert!");
		   }
		   
		   for(int i =0;i<users.size();i++) {
			   System.out.println(users.get(i));
		   }
		   System.out.println("----------------------------");
		   
		  
		   
		   
	   }
}
