
package App;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class profile extends Application {
    public void start (Stage primaryStage){
        final ImageView glassFrame = new ImageView();
       
        //background
        final Image background = new Image(getClass().getResourceAsStream("bluebackground.jpg"));
        final ImageView backFrame = new ImageView();
        backFrame.setImage(background);
        backFrame.setFitHeight(720);
        backFrame.setFitWidth(1080);
       
        //hero
        final Image hero = new Image(getClass().getResourceAsStream("superhero.png"));
        final ImageView heroview = new ImageView();
        heroview.setImage(hero);
        heroview.setFitHeight(400);
        heroview.setFitWidth(200);
        heroview.setLayoutX(750);
        heroview.setLayoutY(150);
       
        //star
        final Image star = new Image(getClass().getResourceAsStream("star.png"));
        final ImageView starview = new ImageView();
        starview.setImage(star);
        starview.setFitHeight(200);
        starview.setFitWidth(200);
        starview.setLayoutX(150);
        starview.setLayoutY(100);
       
        //coin
        final Image coin = new Image(getClass().getResourceAsStream("coin.png"));
        final ImageView coinview = new ImageView();
        coinview.setImage(coin);
        coinview.setFitHeight(200);
        coinview.setFitWidth(200);
        coinview.setLayoutX(150);
        coinview.setLayoutY(350);
       
        //buttons
        final Button b1 = new Button("Statistik/History");
        b1.setLayoutX(100);
        b1.setLayoutY(600);
        b1.setMinWidth(250);
       
        final Button b2 = new Button("Einstellungen");
        b2.setLayoutX(780);
        b2.setLayoutY(50);
        b2.setMinWidth(200);
       
        final Button b3 = new Button("Profil teilen");
        b3.setLayoutX(780);
        b3.setLayoutY(600);
        b3.setMinWidth(200);
       
        final Label l1 = new Label("Punkte");
        l1.setLayoutX(215);
        l1.setLayoutY(430);
        l1.setFont(new Font("Arial", 25));
       
       
        Pane root =new Pane();
        root.getChildren().addAll(backFrame, heroview, starview, coinview, b1, b2, b3, l1);
       
        Scene scene = new Scene(root, 1080,720);
        primaryStage.setTitle("Superhero Profil");
        primaryStage.setScene(scene);
        primaryStage.show();
       
    }
    public static void main(String[] args) {
       
        launch(args);
    }
}
